=== Event Manager ===
Contributors: Aadil Mevafarosh
Tags:Events, Event-Manager 
Requires at least: 4.7
Tested up to: 5.8
Requires PHP:5.6 >
Stable Tag – 0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


This plugin is a practical test plugin it will do the following mentioned things

● Registers a post type ( named Events ) through code.
● A corresponding taxonomy ( named Event Types) through code.
● Register a metabox with a couple fields ( such as Start Date and End Date, Event, Location, Venue)
● Create a page called Events.
● When the page is visited, show filters for start date, end date and event category.
● When the user selects Start date, End date or event category, display related events, matching selection criteria on the same page via Ajax.
● For Start Date & End Date it uses jquery datepicker for date selection.
● Write a shortcode in a plugin to display filters/listing on Events page.







