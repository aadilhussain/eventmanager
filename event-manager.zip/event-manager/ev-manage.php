<?php
/**
 * Plugin Name: Plugin Ev-manager
 * Description: Event manager plugin for test purpose
 * Version: 1.0
 * Author: Aadil Mevafarosh
 * Author URI:
 */
defined('ABSPATH') or die("No script kiddies please!");


class EvManager
{

    // Constructor to add all  add_action, add_shortcode, add_filter functions
    // For the callback name, use this: array($this,'<function name>')
    public function __construct()
    {
        global $post;
        // Adding script and Css to WP admin and front end
        // Add Javascript and CSS for admin screens
        add_action('admin_enqueue_scripts', [$this, 'enqueueAdmin']);

        // Add Javascript and CSS for front-end display
        add_action('wp_enqueue_scripts', [$this, 'enqueueFront']);

        // add the post type and taxonomy on plugin installation
        add_action('init', [$this, 'events_register_post_type']);
        add_action('init', [$this, 'create_events_taxonomy']);
        add_action('init', [$this, 'create_eventtype_entries']);

        // add filter for new event page template
        add_filter('template_include', [$this, 'include_template_function'], 1);


        // Add Event page in custom post type
        add_action('init', [$this, 'create_event_page']);

        //Add metaboxes to event
        add_action('add_meta_boxes', [$this, 'create_event_metabox']);

        // save our metaboxes data
        add_action('save_post', [$this, 'save_event_metabox']);

        // Add shortcode to show it in front page

    }


    //Events register post type is hierarchical as we need events page in front end

    public static function events_register_post_type()
    {
        // Events
        $labels = array(
            'name' => __('Events', 'Eventmania'),
            'singular_name' => __('Event', 'Eventmania'),
            'add_new' => __('New Event', 'Eventmania'),
            'add_new_item' => __('Add New Event', 'Eventmania'),
            'edit_item' => __('Edit Event', 'Eventmania'),
            'new_item' => __('New Event', 'Eventmania'),
            'view_item' => __('View Event', 'Eventmania'),
            'search_items' => __('Search Events', 'Eventmania'),
            'not_found' => __('No Event Found', 'Eventmania'),
            'not_found_in_trash' => __('No Event found in Trash', 'Eventmania'),
        );
        $args = array(
            'labels' => $labels,
            'has_archive' => true,
            'public' => true,
            'hierarchical' => true,
            'show_in_menu' => true,

            'supports' => array('title', 'editor', 'excerpt', 'custom-fields', 'thumbnail', 'page-attributes'
            ),
            'show_ui' => true,
            'menu_position' => 21,

            'menu_icon' => 'dashicons-analytics'
        ,
            'show_in_rest' => true
        );
        register_post_type('Event', $args);

    }

    //Create a custom taxonomy Events type it Event-types for your Events

    public static function create_events_taxonomy()
    {
        // Add new taxonomy, make it hierarchical like categories

        $labels = array(
            'name' => _x('Event-types', 'event-types'),
            'singular_name' => _x('Event-type', 'event-type'),
            'search_items' => __('Search Event-types'),
            'all_items' => __('All Event-types'),
            'parent_item' => __('Parent Event-type'),
            'parent_item_colon' => __('Parent Event-type:'),
            'edit_item' => __('Edit Event-type'),
            'update_item' => __('Update Event-type'),
            'add_new_item' => __('Add New Event-type'),
            'new_item_name' => __('New Event-type Name'),
            'menu_name' => __('Event-types'),
        );

        // Now register the taxonomy
        register_taxonomy('Event-types', array('event'), array(
            'hierarchical' => true,
            'labels' => $labels,
            'show_ui' => true,
            'show_in_rest' => true,
            'show_admin_column' => true,
            'query_var' => true
        ));

    }


    /* ENQUEUE SCRIPTS AND STYLES */

    public static function enqueueAdmin()
    {

        // These two lines allow you to only load the files on the relevant screen, in this case, the editor for a "events" custom post type
        $screen = get_current_screen();
        if (!($screen->base == 'post' && $screen->post_type == 'event')) return;
        wp_enqueue_style('bootstrap', plugins_url('/css/bootstrap.css', __FILE__));
        wp_enqueue_script('bootstrap', plugins_url('/js/bootstrap.min.js', __FILE__), array('jquery'), '1.0', true);
        wp_enqueue_style('jquery-ui');


        //wp_enqueue_script('jquery');
        wp_register_style('jquery-ui', 'https://code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css');
        wp_enqueue_style('jquery-ui');

        wp_enqueue_script('jquery-ui-datepicker');

        wp_enqueue_script('custom-script', plugins_url('/js/custom-script.js', __FILE__), array('jquery'), '1.0', true);

        // wp_enqueue_script('custom-script');

    }


    public static function enqueueFront()
    {
        // Actual enqueues, note the files are in the js and css folders

        // all styles
        wp_enqueue_style('bootstrap', plugins_url('/css/bootstrap.css', __FILE__));
        wp_enqueue_script('bootstrap', plugins_url('/js/bootstrap.min.js', __FILE__), array('jquery'), '1.0', true);
        // all scripts
        wp_enqueue_script('jquery-ui-datepicker');


        wp_enqueue_script('datepicker', 'https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js', array('jquery'), '1.0', false);
        // You need styling for the datepicker. For simplicity I've linked to the jQuery UI CSS on a CDN.
        wp_register_style('jquery-ui', 'https://code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css');
        wp_enqueue_style('jquery-ui');


        wp_enqueue_script('custom-script', plugins_url('/js/custom-script.js', __FILE__), array('jquery'), '1.0', false);

    }

    public static function create_event_page()
    {
        $check_page_exist = get_page_by_title('Events', 'OBJECT', 'event');
// Check if the page already exists
        if (empty($check_page_exist)) {
            $page_id = wp_insert_post(
                array(
                    'comment_status' => 'close',
                    'ping_status' => 'close',
                    'post_author' => 1,
                    'post_title' => ucwords('events'),
                    'post_name' => strtolower(str_replace(' ', '-', trim('events'))),
                    'post_status' => 'publish',
                    'post_content' => 'demo page',
                    'post_type' => 'event',
                    'post_parent' => ''
                )
            );
        }
       // wp_set_post_terms($page_id, 'marriage', 'Event-types');


    }

    public static function create_eventtype_entries()
    {

        wp_insert_term('Marriage', // the term
            'Event-types', // the taxonomy
            array(
                'description' => '',
                'slug' => 'marriage'
            )
        );
        wp_insert_term('Seminar', // the term
            'Event-types', // the taxonomy
            array(
                'description' => '',
                'slug' => 'seminar'
            )
        );
        wp_insert_term('Audition', // the term
            'Event-types', // the taxonomy
            array(
                'description' => '',
                'slug' => 'audition'
            )
        );
        wp_insert_term('Party', // the term
            'Event-types', // the taxonomy
            array(
                'description' => '',
                'slug' => 'party'
            )
        );
        wp_insert_term('Learning Class', // the term
            'Event-types', // the taxonomy
            array(
                'description' => '',
                'slug' => 'learning'
            )
        );
    }

    public static function create_event_metabox()
    {
        $posttypes = ['event'];
        foreach ($posttypes as $screen) {
            add_meta_box(
                'event-metabox',
                'Event Handling Metabox', // Box title
                [self::class, 'content_html'], // Content callback, must be of type callable
                $screen // Post type
            );
        }

    }

    /**
     * Display the meta box HTML to the user.
     *
     * @param \WP_Post $post Post object.
     */
    public static function content_html($post)
    {
        global $post;
        $value = get_post_meta($post->ID, '_venue', true);
        ?>
        <br><br>
        <label for="start_date">Start Date</label>
        <input type="text" id="start_date" name="start_date"
               value="<?php echo get_post_meta($post->ID, '_startdate', true) ?>">
        <label for="end_date">End Date</label>
        <input type="text" id="end_date" name="end_date"
               value="<?php echo get_post_meta($post->ID, '_enddate', true) ?>">

        <br><br>
        <label for="event_venue">Event Venue</label>
        <br>
        <select name="venue" id="venue" class="postbox">
            <option value="">Select a Venue</option>
            <option value="udaipur" <?php selected($value, 'udaipur'); ?>>Udaipur</option>
            <option value="dehli" <?php selected($value, 'dehli'); ?>>Dehli</option>
            <option value="jaipur" <?php selected($value, 'jaipur'); ?>>Jaipur</option>
            <option value="banglore" <?php selected($value, 'banglore'); ?>>Banglore</option>
            <option value="mumbai" <?php selected($value, 'mumbai'); ?>>Mumbai</option>
            <option value="else" <?php selected($value, 'else'); ?>>Else</option>
        </select>
        <br><br>
        <label for="event_start_time">Event Start time</label>

        <input type="time" id="start_timing" name="start_timing"
               value="<?php echo get_post_meta($post->ID, '_starttime', true) ?>">
        <label for="event_start_time">Event Close time</label>

        <input type="time" id="close_timing" name="close_timing"
               value="<?php echo get_post_meta($post->ID, '_closetime', true) ?>">
        <br><br>

        <label for="event_descrption">Event Description</label>
        <br>
        <textarea rows="8" name="description"
                  id="description"><?php echo get_post_meta($post->ID, '_description', true) ?></textarea>

    <?php
    }

    public static function save_event_metabox()
    {
        global $post;
        $post_id = $post->ID;
        print_r($_POST);

        if (array_key_exists('start_date', $_POST)) {
            update_post_meta(
                $post_id,
                '_startdate',
                $_POST['start_date']
            );
        }
        if (array_key_exists('end_date', $_POST)) {
            update_post_meta(
                $post_id,
                '_enddate',
                $_POST['end_date']
            );
        }
        if (array_key_exists('start_timing', $_POST)) {
            update_post_meta(
                $post_id,
                '_starttime',
                $_POST['start_timing']
            );
        }
        if (array_key_exists('close_timing', $_POST)) {
            update_post_meta(
                $post_id,
                '_closetime',
                $_POST['close_timing']
            );
        }
        if (array_key_exists('venue', $_POST)) {
            update_post_meta(
                $post_id,
                '_venue',
                $_POST['venue']
            );
        }
        if (array_key_exists('description', $_POST)) {
            update_post_meta(
                $post_id,
                '_description',
                $_POST['description']
            );
        }


    }


    public static function include_template_function($template_path)
    {
        if (get_post_type() == 'event') {

            if (is_single()) {
                // checks if the file exists in the theme first,
                // otherwise serve the file from the plugin
                if ($theme_file = locate_template(array('single-event.php'))) {
                    $template_path = $theme_file;
                } else {
                    $template_path = plugin_dir_path(__FILE__) . '/single-event.php';
                }
            }
        }
        return $template_path;
    }


}

// We need this available beyond our initial creation, so we can create it as a global
global $myeventobj;

// Create an instance of our class to kick off the whole thing
$myeventobj = new EvManager();