<?php
/**
 * The template for displaying all single event
*/

get_header();
?>

    <main id="primary" class="site-main">

        <?php
        while ( have_posts() ) :
            the_post(); ?>

        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

        <header class="entry-header alignwide">
            <?php the_title( '<h1 class="entry-title">','</h1><h3>-Upcoming Event this year </h3>' ); ?>

            <p>Start Date: <input type="date" id="start_date" name="start_date">
            End Date: <input type="date" id="end_date" name="end_date"></p>
            <p>Event type
                <select name="venue" id="venue" class="postbox">
                    <option value="">Select a type</option>
                    <?php
                    $terms = get_terms([
                        'taxonomy' => 'Event-types',
                        'hide_empty' => false,
                    ]);

                   foreach ($terms as $term){
                   echo '<option name='.$term->name.' id='.$term->term_id.'>'.$term->name.'</option>' ;
                   } ?>

                </select>
        </header><!-- .entry-header -->

        </main>
            <?php endwhile; ?>

        <!-- .entry-content -->
<?php
//get_sidebar();
//get_footer();
?>