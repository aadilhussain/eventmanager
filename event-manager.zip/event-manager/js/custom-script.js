jQuery.noConflict();

(function($) {
	
    $('#start_date').datepicker();
$('#end_date').datepicker();

$('#venue').on('change', function() {
  alert( this.value );


 $.ajax({
    type: 'POST',
    url: '/wp-admin/admin-ajax.php',
    dataType: 'html',
    data: {
    },
    success: function(res) {
      $('.project-tiles').html(res);
    }
  })
});




}(jQuery));